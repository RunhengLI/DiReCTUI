﻿using Microsoft.Maps.MapControl.WPF;
using System;
using System.Xml;

namespace DiReCTUI.Models
{
    /// <summary>
    /// A class that parses and stores an existing record
    /// WIP (optional): multithreading
    /// </summary>
    public class Record
    {
        /// Record location
        public Location Location;

        /// Record Time type "yyMMddHHmmss"
        public string Time { get; protected set; }

        /// Name of the task recorded
        public string TaskName { get; protected set; }

        /// A XmlNode containing its responses
        public XmlNode TaskResponse { get; protected set; }

        /// <summary>
        /// Constructor Method
        /// Parses a XmlNode to obtain its record data
        /// </summary>
        /// <param name="XmlNode">Xml document of a record file</param>
        public Record(XmlDocument XmlDoc)
        {
            Location=new Location();
            foreach(XmlNode inNode in XmlDoc.FirstChild.ChildNodes)
                switch(inNode.Name)
                {
                case "Latitude":
                    Location.Latitude=Double.Parse(inNode.InnerText,System.Globalization.CultureInfo.InvariantCulture);
                    break;
                case "Longitude":
                    Location.Longitude=Double.Parse(inNode.InnerText,System.Globalization.CultureInfo.InvariantCulture);
                    break;
                case "RecordTime":
                    Time=inNode.InnerText;
                    break;
                default:
                    TaskName=inNode.Name;
                    TaskResponse=inNode;
                    break;
                }
        }
    }
}
