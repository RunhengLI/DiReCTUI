﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using DiReCTUI.Views;
using DiReCTUI.Controls;


namespace DiReCTUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// The main window for this DiReCT User Interface
    /// </summary>
    public partial class MainWindow:Window
    {
        /// Stores User name
        private string UserName;

        /// A SOPReader instance to read the list and parse SOP files 
        private SOPReader SOPReader;

        /// <summary>
        /// Constructor method
        /// Displays the main window
        /// Default user name, for testing only
        /// </summary>
        public MainWindow()
        {
            SOPReader=new SOPReader();
            InitializeComponent();
            UserName="User";
            UserMenu.Header=UserName;   
        }

        /// <summary>
        /// Constructor method
        /// Displays the main window
        /// </summary>
        /// <param name="name">User name used during login</param>
        public MainWindow(string name)
        {
            SOPReader=new SOPReader();
            InitializeComponent();
            UserName=name;
            UserMenu.Header=UserName;          
        }

        /// <summary>
        /// Event which is invoked each time TabControl selection changes, displays different UserControls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainTab_Change(object sender,RoutedEventArgs e)
        {
            ///Observations selected, generates new instance at the first time loaded, then refresh it EVERY TIME loaded, as there may exist newly-downloaded SOPs
            if(ObservationsTab.IsSelected)
            {
                if(ObservationsControl.Content==null)
                    ObservationsControl.Content=new SelectionView(SOPReader);
                else
                    (ObservationsControl.Content as SelectionView).Refresh();
            }

            ///Recorders list selected, generates new instance at the first time loaded
            if(RecordersTab.IsSelected)
            {
                if(RecordersControl.Content==null)
                    RecordersControl.Content=new RecordersView();
            }

            ///SOP list selected, generates new instance at the first time loaded
            if(SOPListTab.IsSelected)
            {
                if(SOPListControl.Content==null)
                    SOPListControl.Content=new SOPListView(SOPReader);
            }
        }

        /// <summary>
        /// Event which is invoked each time User->Signout is clicked, asks if the user would like to sign out
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UserSignoutMenu_Click(object sender,RoutedEventArgs e)
        {
            if(MessageBox.Show("Are you sure to sign out?\nAll unsaved changes will be lost!","",MessageBoxButton.OKCancel)==MessageBoxResult.OK)
            {
                ///Close the main window and switch back to login window
                new SigninWindow(UserName).Show();
                this.Close();
            }
        }
    }
}