﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using DiReCTUI.Controls;
using System.Xml;
using Microsoft.Maps.MapControl.WPF;
using DiReCTUI.Models;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for ObservationsView.xaml
    /// A user control that presents Bingmap and other tools concerning the selected SOP 
    /// </summary>
    public partial class ObservationsView:UserControl
    {
        /// A SOP instance for parsing Xml file of the selected SOP
        private SOP SOP;

        /// Stores parent ScrollView
        private ScrollViewer Scrollviewer;

        /// <summary>
        /// Constructor method
        /// Obtains and parses Xml file of the SOP for its children to use
        /// </summary>
        /// <param name="XmlDoc">XmlDocument file of the selected SOP</param>
        /// <param name="s">Parent ScrollView to be revealed on closing</param>
        public ObservationsView(XmlDocument XmlDoc,ScrollViewer s)
        {
            InitializeComponent();
            SOP=new SOP(XmlDoc.FirstChild);
            Scrollviewer=s;
            ObservationsTab.SelectedIndex=0;
        }

        /// <summary>
        /// Event which is invoked each time TabControl selection changes, displays various UserControls concerning this SOP
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ObservationsTab_Change(object sender,RoutedEventArgs e)
        {

            ///Map selected, generates new instance at the first time loaded
            if(MapTab.IsSelected)
            {
                if(MapControl.Content==null)
                {
                    ///WIP: Fixed location for demo only
                    ///Should fetch user GPS position on a real tablet
                    Location location=new Location(25.04133,121.6133);
                    MapControl.Content=new MapView(location,SOP);
                }
            }

            ///Record list selected, generates new instance EVERY TIME loaded, as there may exist newly-generated records
            if(RecordListTab.IsSelected)
            {
                if(RecordListControl.Content==null)
                {
                    RecordListControl.Content=new RecordListView(SOP.Name);
                }
            }

            ///Background selected
            ///WIP
            if(BackgroundTab.IsSelected)
            { }

            ///Task view selected
            ///WIP
            if(TaskViewTab.IsSelected)
            { }
        }

        /// <summary>
        /// Event which is invoked each time ReturnButton is clicked, asks if the user would like to leave
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ReturnButton_Click(object sender,RoutedEventArgs e)
        {
            if(MessageBox.Show("Return to SOP Selection?\nAll unsaved changes will be lost!","",MessageBoxButton.OKCancel)==MessageBoxResult.OK)
            {

                ///Leaves the ObservationsView and returns to SOP selection
                ((ContentControl)this.Parent).Content=null;
                Scrollviewer.Visibility=Visibility.Visible;
            }
            
        }

    }
}
