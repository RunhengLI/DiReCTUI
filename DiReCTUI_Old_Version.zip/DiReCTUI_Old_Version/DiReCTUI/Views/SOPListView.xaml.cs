﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using DiReCTUI.Controls;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for SOPListView.xaml
    /// A user control that displays all local SOP status and download option
    /// WIP: Real download system
    /// </summary>
    public partial class SOPListView:UserControl
    {
        /// Stores SOPReader
        private SOPReader SOPReader;

        /// <summary>
        /// Constructor method
        /// Obtains and Updates SOPReader from the main window
        /// </summary>
        /// <param name="s">SOPReader to be displayed and updated</param>
        public SOPListView(SOPReader s)
        {
            InitializeComponent();
            SOPReader=s;
            Refresh();
        }

        /// <summary>
        /// Displays status of local SOPs and download option
        /// </summary>
        private void Refresh()
        {

            ///Constant number of columns in the grid
            const int columnNum=3;
            int SOPNum=SOPReader.SOPNameList.Count;

            ///Number of rows needed to put all elements in the grid
            int rowNum=(int)Math.Ceiling((double)SOPNum/(double)columnNum);

            SOPGrid.ColumnDefinitions.Clear();
            SOPGrid.RowDefinitions.Clear();
            SOPGrid.Children.Clear();

            for(int i=0;i<columnNum;i++)
                SOPGrid.ColumnDefinitions.Add(new ColumnDefinition());
            
            for(int i=0;i<rowNum;i++)
                SOPGrid.RowDefinitions.Add(new RowDefinition());

            ///TextBlocks containing names of each SOP 
            TextBlock[] textBlock=new TextBlock[SOPNum];
            for(int i=0;i<SOPNum;i++)
            {
                textBlock[i]=new TextBlock();

                ///If there exists SOP file of this name
                if(SOPReader.HasXml(i))
                {
                    textBlock[i].Background=Brushes.LightGreen;
                }
                ///If there doesn't exist SOP file of this name, enable clicking
                else
                {
                    textBlock[i].Background=Brushes.LightGray;

                    ///Lambda function which is invoked each time a TextBlock is clicked, asks if the user would like to download the related SOP file
                    ///WIP: Add a download method here
                    textBlock[i].PreviewMouseDown+=(senderTextBlock,clickEvent) =>
                    {
                        int index=i;
                        if(MessageBox.Show("DownLoad data of SOP ?\n\n"+SOPReader.SOPNameList[Array.IndexOf(textBlock,(TextBlock)senderTextBlock)],"",MessageBoxButton.OKCancel)==MessageBoxResult.OK)
                        {

                            ///Update SOPReader
                            SOPReader.SOPFileLoad(SOPReader.SOPNameList[Array.IndexOf(textBlock,(TextBlock)senderTextBlock)]);
                            
                            ///Update this UserControl
                            Refresh();
                        }     
                    };
                }
                textBlock[i].Text="\n\n\n"+SOPReader.SOPNameList[i]+"\n\n\n";
                textBlock[i].TextAlignment=TextAlignment.Center;
                textBlock[i].Width=195;
                textBlock[i].Height=135;
                textBlock[i].Margin=new Thickness(0,0,0,5);


                SOPGrid.Children.Add(textBlock[i]);
                Grid.SetRow(textBlock[i],(i-i%columnNum)/columnNum);
                Grid.SetColumn(textBlock[i],i%columnNum);
            }
        }
    }
}
