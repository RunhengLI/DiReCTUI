﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using DiReCTUI.Controls;
using Microsoft.Maps.MapControl.WPF;
using System.Xml;
using DiReCTUI.Models;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for RecordView.xaml
    /// A user control that generates a dynamic servey according to the SOP file, which the user can fill in.
    /// </summary>
    public partial class RecordView:UserControl
    {

        /// Stores current SOP task
        private SOPTask SOPTask;

        /// Stores parent Grid
        private Grid MapGrid;

        /// Stores user location
        private Location Location;

        /// Stores SOP name
        private string SOPName;

        /// <summary>
        /// Constructor method
        /// Obtains useful data and generates a survey
        /// </summary>
        /// <param name="s">The current SOP task</param>
        /// <param name="mapGrid">Parent Grid to be revealed on closing</param>
        /// <param name="l">User location, used only to generate record file</param>
        /// <param name="name">SOP name, used only to generate record file</param>
        public RecordView(XmlNode XmlNode,Grid mapGrid,Location l,string name)
        {
            InitializeComponent();
            SOPTask=new SOPTask(XmlNode);
            MapGrid=mapGrid;
            Location=l;
            SOPName=name;

            Refresh();
        }

        /// <summary>
        /// Event which is invoked each time SaveButton is clicked, creates a RecordWriter instance to generate the record file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveButton_Click(object sender,RoutedEventArgs e)
        {

            ///A list to collect all responses in order
            List<string> responseList=new List<string>();

            for(int i=0;i<SOPTask.SubTaskList.Count;i++)
            {
                switch(SOPTask.SubTaskList[i].Type)
                {
                    case "enum":
                        responseList.Add(SOPTask.SubTaskList[i].defaultList[(RecordGrid.Children[2*i+1] as ListBox).SelectedIndex]);
                        break;
                    default:
                        responseList.Add((RecordGrid.Children[2*i+1] as TextBox).Text);
                        break;
                }
            }
            RecordWriter recordWriter=new RecordWriter(SOPName,SOPTask,responseList,Location);
            MessageBox.Show("New record saved","",MessageBoxButton.OK);

            ///Leaves the survey and returns to the map
            ((ContentControl)this.Parent).Content=null;
            MapGrid.Visibility=Visibility.Visible;
        }

        /// <summary>
        /// Event which is invoked each time AbortButton is clicked, asks if the user would like to leave
        /// WIP(optional): save unfinished survey when leaving
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AbortButton_Click(object sender,RoutedEventArgs e)
        {
            if(MessageBox.Show("Abort recording?\nAll unsaved changes will be lost!","",MessageBoxButton.OKCancel)==MessageBoxResult.OK)
            {

                ///Leaves the survey and returns to the map
                ((ContentControl)this.Parent).Content=null;
                MapGrid.Visibility=Visibility.Visible;
            }     
        }

        /// <summary>
        /// Generates and displays the survey
        /// WIP: more type options (map polygons, charts, photos...), by invoking new UserControls
        /// </summary>
        private void Refresh()
        {
            int subTaskNum=SOPTask.SubTaskList.Count;

            ///Sets row definitions, for both questions and responses
            for(int i=0;i<2*subTaskNum;i++)
                RecordGrid.RowDefinitions.Add(new RowDefinition());

            for(int i=0;i<subTaskNum;i++)
            {
                ///question labels
                TextBlock textBlock=new TextBlock();
                textBlock.Text=SOPTask.SubTaskList[i].Name;
                textBlock.Height=40;
                RecordGrid.Children.Add(textBlock);
                Grid.SetRow(textBlock,2*i);

                switch(SOPTask.SubTaskList[i].Type)
                {

                    ///for enum type questions, create a ListBox for choosing
                    case "enum":
                        ListBox listBox=new ListBox();
                        foreach(string s in SOPTask.SubTaskList[i].defaultList)
                            listBox.Items.Add(s);
                        listBox.SelectedIndex=0;
                        listBox.Width=450;
                        RecordGrid.Children.Add(listBox);
                        Grid.SetRow(listBox,2*i+1);
                        break;

                    ///for other types, just create a TextBox (or a button to invoke UserControls in the future)
                    default:
                        TextBox textBox=new TextBox();
                        textBox.Text=SOPTask.SubTaskList[i].defaultList[0];
                        textBox.Width=450;
                        RecordGrid.Children.Add(textBox);
                        Grid.SetRow(textBox,2*i+1);
                        break;
                }
            }
        }
    }
}
