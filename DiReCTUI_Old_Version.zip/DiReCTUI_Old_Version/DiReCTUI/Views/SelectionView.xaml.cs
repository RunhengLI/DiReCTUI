﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using DiReCTUI.Controls;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for SelectionView.xaml
    /// A user control that provides selection among existing SOPs 
    /// </summary>
    public partial class SelectionView:UserControl
    {
        /// Stores Parent SOPReader
        private SOPReader SOPReader;

        /// <summary>
        /// Constructor method
        /// Obtains SOPReader from the main window
        /// </summary>
        /// <param name="s">SOPReader instance containing Xml files of each SOP</param>
        public SelectionView(SOPReader s)
        {
            SOPReader=s;
            InitializeComponent();
            Refresh();
        }

        /// <summary>
        /// Displays TextBlocks of SOPs for selection
        /// </summary>
        public void Refresh()
        {

            ///Constant number of columns in the grid
            const int columnNum=3;
            int SOPNum=SOPReader.SOPNameList.Count();

            ///Number of rows needed to put all elements in the grid
            int rowNum=(int)Math.Ceiling((double)SOPNum/(double)columnNum);

            SelectionGrid.ColumnDefinitions.Clear();
            SelectionGrid.RowDefinitions.Clear();
            SelectionGrid.Children.Clear();

            for(int i=0;i<columnNum;i++)
                SelectionGrid.ColumnDefinitions.Add(new ColumnDefinition());

            for(int i=0;i<rowNum;i++)
                SelectionGrid.RowDefinitions.Add(new RowDefinition());

            ///TextBlocks containing containing names of each SOP 
            TextBlock[] textBlock=new TextBlock[SOPNum];
            for(int i=0;i<SOPNum;i++)
            {
                textBlock[i]=new TextBlock();

                ///If there exists SOP file for this name, add click events
                if(SOPReader.HasXml(i))
                {
                    textBlock[i].Background=Brushes.AliceBlue;
                    
                    ///Lambda function which is invoked each time a TextBox is clicked
                    textBlock[i].PreviewMouseDown+=(senderTextBlock,clickEvent)=>
                    {
                        Select(Array.IndexOf(textBlock,senderTextBlock));
                    };
                }
                ///If there doesn't exist SOP file for this name
                else
                {
                    textBlock[i].Background=Brushes.LightGray;
                }

                textBlock[i].Text="\n\n\n"+SOPReader.SOPNameList[i]+"\n\n\n";
                textBlock[i].TextAlignment=TextAlignment.Center;
                textBlock[i].Width=195;
                textBlock[i].Height=135;
                textBlock[i].Margin=new Thickness(0,0,0,5);

                SelectionGrid.Children.Add(textBlock[i]);
                Grid.SetRow(textBlock[i],(i-i%columnNum)/columnNum);
                Grid.SetColumn(textBlock[i],i%columnNum);
            }
        }

        /// <summary>
        /// Creates a new ObservationView instance of the selected SOP
        /// </summary>
        /// <param name="index">Index of the selected SOP in the SOP list</param>
        private void Select(int index)
        {
            ObservationsControl.Content=new ObservationsView(SOPReader.SOPXmlList[SOPReader.SOPNameList[index]],SelectionScroll);
            SelectionScroll.Visibility=Visibility.Collapsed;
        }
    }
}
