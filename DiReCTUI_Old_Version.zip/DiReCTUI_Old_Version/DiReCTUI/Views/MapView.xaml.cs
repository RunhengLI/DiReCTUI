﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

using DiReCTUI.Controls;
using Microsoft.Maps.MapControl.WPF;
using System.Xml;
using DiReCTUI.Models;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for MapView.xaml
    /// A user control that displays a Bingmap and a menu for generating new records 
    /// </summary>
    public partial class MapView:UserControl
    {
        /// Stores SOP
        private SOP SOP;

        /// <summary>
        /// Constructor method
        /// Generates a map and a menu according to the selected SOP
        /// </summary>
        /// <param name="location">User location</param>
        /// <param name="s">Selected SOP</param>
        public MapView(Location location,SOP s)
        {
           
            InitializeComponent();
            SOP=s;
            ClearPin();
            MainMap.Center=location;

            MainMap.CredentialsProvider=new ApplicationIdCredentialsProvider("CI5wNvynWPhc3KSG9TtB~_ixP3ePbIXvfHTVmYF2cww~AszWGhm4xOBPFALpjc4l9xjbllDA2cCKXp6WYLLAVg-4O-HasQfPIcnaNm6OY2s3");
            MainMap.ZoomLevel=16;

            foreach(LocationTask l in SOP.LocationTaskList)
                AddStaticPin(l);
            AddDraggablePin(location);

            DisplayMenu();
        }

        /// <summary>
        /// Clears all pushpins on the map
        /// </summary>
        public void ClearPin()
        {
            MainMap.Children.Clear();
        }

        /// <summary>
        /// Adds a static pushpin on the map
        /// </summary>
        /// <param name="locationTask">A location and its list of recommended tasks</param>
        public void AddStaticPin(LocationTask locationTask)
        {
            Pushpin newPin=new Pushpin();
            newPin.Location=locationTask.Location;
            newPin.Background=Brushes.Gray;

            string task="Please Record:\n";
            foreach(string s in locationTask.TaskList)
                task=task+s+"\n";
            newPin.ToolTip=task;

            ///Lambda function which is invoked each time a static pin is clicked
            newPin.PreviewMouseDown+=(senderPin,clickEvent)=>
            {
                MessageBox.Show(task,"",MessageBoxButton.OK);               
            };

            MainMap.Children.Add(newPin);
        }

        /// <summary>
        /// Adds a draggable pushpin on the map
        /// WIP: Draggable for demo only, should not be draggable on a real tablet
        /// </summary>
        /// <param name="location">Pushpin Location</param>
        public void AddDraggablePin(Location location)
        {
            DraggablePin newPin=new DraggablePin(MainMap);
            newPin.Location=location;
            MainMap.Children.Add(newPin);
        }

        /// <summary>
        /// Updates DraggablePin location
        /// Currently Unused, should be called regularly to update user position on a real tablet
        /// </summary>
        /// <param name="location"></param>
        public void PinMove(Location location)
        {

            ///The user pushpin is the last children, makes use of that
            (MainMap.Children[MainMap.Children.Count-1] as DraggablePin).Location=location;
        }

        /// <summary>
        /// Event which is invoked each time MenuButton is clicked, toggles menu visibility
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MapButton_Click(object sender,RoutedEventArgs e)
        {
            if(MenuGrid.Visibility==Visibility.Collapsed)
                MenuGrid.Visibility=Visibility.Visible;
            else
                MenuGrid.Visibility=Visibility.Collapsed;
        }

        /// <summary>
        /// Displays task menu
        /// </summary>
        private void DisplayMenu() 
        {
            MenuGrid.Visibility=Visibility.Collapsed;

            List<String> taskList=new List<String>();
            foreach(XmlNode taskNode in SOP.TaskNodeList)
                taskList.Add(taskNode.Name);
            int taskNum=taskList.Count;

            for(int i=0;i<taskNum;i++)
                MenuGrid.RowDefinitions.Add(new RowDefinition());

            TextBlock[] textBlock=new TextBlock[taskNum];
            for(int i=0;i<taskNum;i++)
            {
                ///TextBlocks holding task names
                textBlock[i]=new TextBlock();
                textBlock[i].Height=30;
                textBlock[i].Text=taskList[i];
                textBlock[i].FontSize=22;
                textBlock[i].TextAlignment=TextAlignment.Right;

                ///Lambda function which is invoked each time a task in the menu is clicked
                textBlock[i].PreviewMouseDown+=(senderTextBlock,clickEvent)=>
                {
                    CreateRecord(Array.IndexOf(textBlock,(TextBlock)senderTextBlock));
                };

                MenuGrid.Children.Add(textBlock[i]);
                Grid.SetRow(textBlock[i],i);
            }
        }

        /// <summary>
        /// Creates a RecordView instance of the selected task
        /// </summary>
        /// <param name="index">Index of the selected task in the task list</param>
        private void CreateRecord(int index)
        {
            Location location=((DraggablePin)MainMap.Children[MainMap.Children.Count-1]).Location;
            RecordControl.Content=new RecordView(SOP.TaskNodeList[index],MapGrid,location,SOP.Name);
            MapGrid.Visibility=Visibility.Collapsed;
        }
    }
}
