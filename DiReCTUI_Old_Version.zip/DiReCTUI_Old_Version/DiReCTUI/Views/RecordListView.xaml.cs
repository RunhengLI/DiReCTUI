﻿using System.Windows.Controls;

using DiReCTUI.Controls;
using DiReCTUI.Models;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for RecordListView.xaml
    /// A user control that displays all previous records of a specific SOP 
    /// </summary>
    public partial class RecordListView:UserControl
    {
        /// A RecordReader instance for loading and parsing record files
        private RecordReader RecordReader;

        /// <summary>
        /// Constructor method
        /// Reads record files of a SOP
        /// </summary>
        /// <param name="SOPName">Name of the SOP whose records are to be read</param>
        public RecordListView(string SOPName)
        {
            InitializeComponent();
            RecordReader=new RecordReader(SOPName);

            ///Add records to the TabControl
            RecordListTab.Items.Clear();
            foreach(Record r in RecordReader.RecordList)
            {
                TabItem tabItem=new TabItem();
                tabItem.Width=150;
                tabItem.Header=r.TaskName+"\n"+r.Time;
                RecordListTab.Items.Add(tabItem);
            }
            RecordListTab.SelectedIndex=0;
        }

        /// <summary>
        /// Event which is invoked each time TabControl selection changes, displays record details in its Content
        /// WIP: display style
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RecordListTab_Change(object sender,SelectionChangedEventArgs e)
        {
            int index=RecordListTab.SelectedIndex;
            TextBlock textBlock=new TextBlock();
            textBlock.Text="Latitude: "+RecordReader.RecordList[index].Location.Latitude+"\nLongitude: "+RecordReader.RecordList[index].Location.Longitude+"\n\nRecord:\n";
            textBlock.Text+=RecordReader.RecordList[index].TaskResponse.InnerXml;
            (RecordListTab.Items[index] as TabItem).Content=textBlock;

            ///Flag event as handled, or it'll be passsed to upper user controls
            e.Handled=true;
        }
    }
}
