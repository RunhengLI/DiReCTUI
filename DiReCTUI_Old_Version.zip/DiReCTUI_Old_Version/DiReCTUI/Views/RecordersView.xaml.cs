﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DiReCTUI.Views
{
    /// <summary>
    /// Interaction logic for RecordersView.xaml
    /// A user control that displays a list of all recorders of the event
    /// WIP: make this list dynamic by reading an Xml file
    /// </summary>
    public partial class RecordersView:UserControl
    {
        /// <summary>
        /// Constructor method
        /// </summary>
        public RecordersView()
        {
            InitializeComponent();
            Display();
        }

        /// <summary>
        /// Displays a list of recorders
        /// </summary>
        private void Display()
        {
            ///Constant number of columns in the grid
            const int columnNum=3;

            ///Number of recorders read
            ///WIP: Hard-coded for demo only, should be based on input data on a real tablet
            const int recorderNum=14;

            ///Number of rows needed to put all elements in the grid
            int rowNum=(int)Math.Ceiling((double)recorderNum/(double)columnNum);

            for(int i=0;i<columnNum;i++)
                RecordersGrid.ColumnDefinitions.Add(new ColumnDefinition());

            for(int i=0;i<rowNum;i++)
                RecordersGrid.RowDefinitions.Add(new RowDefinition());

            for(int i=0;i<recorderNum;i++)
            {

                ///TextBlocks containing information of each recorder
                TextBlock recordersTextBlock=new TextBlock();
                
                ///String to display on each TextBlock
                ///WIP
                recordersTextBlock.Text="\nRecorder Name: "+i+"\n\nPhone Number:\n"+"0000000000"+"\n\n";

                recordersTextBlock.TextAlignment=TextAlignment.Center;
                recordersTextBlock.Background=Brushes.LightYellow;
                recordersTextBlock.Width=195;
                recordersTextBlock.Height=135;
                recordersTextBlock.Margin=new Thickness(0,0,0,5);
                RecordersGrid.Children.Add(recordersTextBlock);
                Grid.SetRow(recordersTextBlock,(i-i%columnNum)/columnNum);
                Grid.SetColumn(recordersTextBlock,i%columnNum);
            }
        }
    }
}
